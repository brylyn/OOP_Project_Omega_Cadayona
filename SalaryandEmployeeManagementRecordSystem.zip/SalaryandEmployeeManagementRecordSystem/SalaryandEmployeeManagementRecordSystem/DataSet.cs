﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SalaryandEmployeeManagementRecordSystem
{
    class DataSet
    {

        public static List<Employee> EmployeeList = new List<Employee>();
        public static List<User> UserList = new List<User>();
        public static List<Calculation> CalculationList = new List<Calculation>();


    }
}
